Readme

GDAL KML 2.2 Testing 
Driver Documentation is here: http://gdal.org/ogr/drv_libkml.html

Example files that pass the test
* test_ogrlibkml.kml : test all points except ATC 22, 23, 11, 33, 53.
* test_ogrlibkml.kmz: same in kmz format
* test_ogrlibkml_update.kml: test ATC 22 and 23
* test_superoverlay.kmz: test ATC 11, 33 and 53
